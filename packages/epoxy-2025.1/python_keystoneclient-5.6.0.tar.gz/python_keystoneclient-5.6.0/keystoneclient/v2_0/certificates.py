# Copyright 2014 IBM Corp.
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.


class CertificatesManager(object):
    """Manager for certificates."""

    def __init__(self, client):
        self._client = client

    def get_ca_certificate(self):
        """Get CA certificate.

        :returns: PEM-formatted string.
        :rtype: str

        """
        resp, body = self._client.get('/certificates/ca', authenticated=False)
        return resp.text

    def get_signing_certificate(self):
        """Get signing certificate.

        :returns: PEM-formatted string.
        :rtype: str

        """
        resp, body = self._client.get('/certificates/signing',
                                      authenticated=False)
        return resp.text
