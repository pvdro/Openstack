"""
.. codeauthor:: Tsuyoshi Hombashi <tsuyoshi.hombashi@gmail.com>
"""

from .__version__ import __author__, __copyright__, __email__, __license__, __version__
from ._func import detect_file_encoding
from ._mbstrdecoder import MultiByteStrDecoder


__all__ = (
    "__author__",
    "__copyright__",
    "__email__",
    "__license__",
    "__version__",
    "detect_file_encoding",
    "MultiByteStrDecoder",
)
