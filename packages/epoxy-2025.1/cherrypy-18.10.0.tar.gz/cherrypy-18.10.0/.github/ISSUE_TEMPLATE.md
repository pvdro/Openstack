<!--
**** DELETE THIS BLOCK ****  

Thanks for filing an issue!  Please keep issues limited to bug reports,
feature requests, and other general issues. For support questions, please feel
free to reach out on stackoverflow:
https://stackoverflow.com/questions/tagged/cherrypy

**** /DELETE THIS BLOCK ****  
-->

**I'm submitting a ...**
- [ ] bug report
- [ ] feature request
- [ ] question about the decisions made in the repository

**Do you want to request a *feature* or report a *bug*?**



**What is the current behavior?**



**If the current behavior is a bug, please provide the steps to reproduce and if possible a screenshots and logs of the problem. If you can, show us your code.**



**What is the expected behavior?**



**What is the motivation / use case for changing the behavior?**



**Please tell us about your environment:**

- Cheroot version: X.X.X
- CherryPy version: X.X.X
- Python version: 3.6.X
- OS: XXX
- Browser: [all | Chrome XX | Firefox XX | IE XX | Safari XX | Mobile Chrome XX | Android X.X Web Browser | iOS XX Safari | iOS XX UIWebView | iOS XX WKWebView ]



**Other information** (e.g. detailed explanation, stacktraces, related issues, suggestions how to fix, links for us to have context, e.g. stackoverflow, gitter, etc.)
