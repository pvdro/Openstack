------------------
Contributing
------------------

.. include:: ../CONTRIBUTING.rst
