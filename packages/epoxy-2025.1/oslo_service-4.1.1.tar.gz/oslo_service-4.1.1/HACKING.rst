oslo.service Style Commandments
===============================

Read the OpenStack Style Commandments https://docs.openstack.org/hacking/latest/
