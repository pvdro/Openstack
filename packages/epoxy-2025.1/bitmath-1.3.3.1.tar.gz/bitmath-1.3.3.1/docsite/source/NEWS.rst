.. include:: ../../NEWS.rst

