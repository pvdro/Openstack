.. gnocchiclient documentation master file, created by
   sphinx-quickstart on Tue Jul  9 22:26:36 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Python bindings and command line tool to the Gnocchi API
========================================================

This is a client for `Gnocchi`_. There's :doc:`a Python API <api>` (the
:mod:`gnocchiclient` module), and a :doc:`command-line script <shell>`
(installed as :program:`gnocchi`). Each implements the entire Gnocchi API.

.. seealso::

    You may want to read the `Gnocchi documentation`__ to get an idea of the
    concepts. By understanding the concepts this library and client should make
    more sense.

    __ http://gnocchi.osci.io

.. _Gnocchi: http://gnocchi.osci.io

Contents:

.. toctree::
   :maxdepth: 2

   installation
   shell
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

