.. cotyledon documentation master file, created by
   sphinx-quickstart on Tue Jul  9 22:26:36 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to cotyledon's documentation!
========================================================

Contents:
=========

.. toctree::
   :maxdepth: 2

   installation
   api
   examples
   non-posix-support
   oslo-service-migration
   contributing

.. include:: ../../README.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

