# Copyright 2018 Red Hat, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from . import ext
from . import page_context
from .paths import *  # noqa
from .version import version_info


__version__ = version_info.version_string()


def setup(app):
    ext.setup(app)
    page_context.setup(app)
    return {
        'parallel_read_safe': True,
        'parallel_write_safe': True,
        'version': __version__,
    }
