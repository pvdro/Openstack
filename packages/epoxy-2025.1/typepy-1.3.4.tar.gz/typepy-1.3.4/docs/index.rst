Welcome to typepy's documentation!
======================================

.. raw:: html

    <div class='ghscard' src='//raw.githubusercontent.com/thombashi/thombashi.github.io/master/data/thombashi_typepy.json'></div>
    <script src='//cdn.jsdelivr.net/gh/thombashi/ghscard@master/dist/ghscard.min.js'></script>
    <br />
    <br />

.. toctree::
   :caption: Table of Contents
   :maxdepth: 3
   :numbered:

   pages/introduction/index
   pages/reference/index
   pages/links


Indices and tables
==================

* :ref:`genindex`
