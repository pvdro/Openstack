class SpecialValue(object):
    pass
