# Copyright (c) 2015 The Johns Hopkins University/Applied Physics Laboratory
# All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import logging
import sys

from kmip.core import enums
from kmip.demos import utils

from kmip.pie import client
from kmip.pie import objects


if __name__ == '__main__':
    logger = utils.build_console_logger(logging.INFO)

    parser = utils.build_cli_parser()
    opts, args = parser.parse_args(sys.argv[1:])

    config = opts.config

    algorithm = enums.CryptographicAlgorithm.AES
    length = 128
    value = (
        b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E'
        b'\x0F')
    usage_mask = [enums.CryptographicUsageMask.ENCRYPT,
                  enums.CryptographicUsageMask.DECRYPT]
    name = 'Demo Symmetric Key'

    key = objects.SymmetricKey(algorithm, length, value, usage_mask, name)
    key.operation_policy_name = opts.operation_policy_name

    # Build the client and connect to the server
    with client.ProxyKmipClient(
            config=config,
            config_file=opts.config_file
    ) as client:
        try:
            uid = client.register(key)
            logger.info("Successfully registered symmetric key with ID: "
                        "{0}".format(uid))
        except Exception as e:
            logger.error(e)
