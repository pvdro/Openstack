.. include:: /includes/_links.rst

Downloads
=========

.. toctree::
   :maxdepth: 2

The PySMI software is provided under terms and conditions of BSD-style
license, and can be freely downloaded from `PySMI PyPI package`_.

Besides official releases, if you want to try the cutting-edge development
code then it could be taken from `PySMI GitHub repository`_. It may
be less stable in regards to general operation and changes to public
interfaces, but it's first to contain fixes to recently discovered bugs.

The best way to obtain PySMI and dependencies is to run:

.. code-block:: bash

   pip install pysmi-lextudio

In case of any issues, please open a new `GitHub issue`_ so we could try to
help out.
